package com.talhaatif.jobportalclient

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.talhaatif.jobportalclient.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Set up BottomNavigationView
        binding.bottomNavigation.setOnNavigationItemSelectedListener { item ->
            var selectedFragment: Fragment? = null
            when (item.itemId) {
                R.id.navigation_home -> selectedFragment = HomeFragment()
                R.id.navigation_profile -> selectedFragment = ProfileFragment()
            }
            if (selectedFragment != null) {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, selectedFragment)
                    .commit()
            }
            true
        }

        // Set default fragment
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, HomeFragment())
                .commit()
        }
    }
//        binding.shimmerViewContainer.visibility = View.VISIBLE
//        binding.shimmerViewContainer.startShimmer() // Start shimmer here
       // setupRecyclerView()

       // fetchNotes()
//
//        datePickers = DatePickers(this, ::applyDateRangeFilter)

//        // Add text change listener to the search bar
//        binding.searchBar.addTextChangedListener { text ->
//            currentQuery = text.toString().trim()
//            filterNotes()
//        }
//
//        // Set up click listener for filter icon
//        binding.filterIcon.setOnClickListener {
//            datePickers.showDatePickerDialog()
//        }
//        // add item
//        binding.fab.setOnClickListener {
//            startActivityForResult(Intent(this, AddNotesActivity::class.java), EDIT_NOTE_REQUEST_CODE)
//        }
//        // settings
//        binding.settingsIcon.setOnClickListener {
//            startActivity(Intent(this,ProfileUpdate::class.java))
//        }
    }

//    private fun filterNotes() {
//        filteredList.clear()
//        filteredList.addAll(notesList.filter { note ->
//            val matchesQuery = note.noteTitle.contains(currentQuery, ignoreCase = true)
//            val matchesDateRange = if (currentStartDate != null && currentEndDate != null) {
//                val noteDate = note.noteDate?.toDate()
//                noteDate != null && noteDate in currentStartDate!!..currentEndDate!!
//            } else {
//                true
//            }
//            matchesQuery && matchesDateRange
//        })
//        noteAdapter.updateNotes(filteredList)
//    }
//
//    private fun setupRecyclerView() {
//        noteAdapter = NoteAdapter(filteredList, this) // Use filteredList
//        binding.rvNotes.layoutManager = LinearLayoutManager(this)
//        binding.rvNotes.adapter = noteAdapter
//    }
//
//    private fun fetchNotes() {
//        val uid = util.getLocalData(this, "uid")
////        Toast.makeText(this, "User ID: $uid", Toast.LENGTH_SHORT).show()
//        Variables.db.collection("notes")
//            .whereEqualTo("uid", uid)
//            .get()
//            .addOnSuccessListener { result ->
//                notesList.clear()
//                for (document in result) {
//                    val note = document.toObject(Note::class.java)
//                    notesList.add(note)
//                }
//                filterNotes() // Reapply filter and search after fetching notes
//                binding.shimmerViewContainer.stopShimmer()
//                binding.shimmerViewContainer.visibility = View.GONE
//
//                Log.d("MainActivity", "Number of notes: ${notesList.size}")
//
//                if (notesList.isEmpty()) {
//                    binding.noDataText.visibility = View.VISIBLE
//                    binding.rvNotes.visibility = View.GONE
//                } else {
//                    binding.noDataText.visibility = View.GONE
//                    binding.rvNotes.visibility = View.VISIBLE
//                }
//            }
//            .addOnFailureListener { exception ->
//                Variables.displayErrorMessage("Error getting notes: ${exception.message}", this)
//                Log.e("MainActivity", "Error getting notes: ${exception.message}")
//                binding.shimmerViewContainer.stopShimmer()
//                binding.shimmerViewContainer.visibility = View.GONE
//            }
//    }
//
//    private fun applyDateRangeFilter(startDate: Date?, endDate: Date?) {
//        currentStartDate = startDate
//        currentEndDate = endDate
//        filterNotes() // Reapply filters based on the new date range
//    }
//
//    companion object {
//        const val EDIT_NOTE_REQUEST_CODE = 1
//    }
//
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == EDIT_NOTE_REQUEST_CODE && resultCode == RESULT_OK) {
//            val noteUpdated = data?.getBooleanExtra("noteUpdated", false) ?: false
//            if (noteUpdated) {
//
//                fetchNotes()
//                if(this.currentQuery != ""){
//                    this.filterNotes()
//                }
//                if (currentStartDate!=null && currentEndDate!=null){
//                    this.filterNotes()
//                }
//            }
//        }
//    }

